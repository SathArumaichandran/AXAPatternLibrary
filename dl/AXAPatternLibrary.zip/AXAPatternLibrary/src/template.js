// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"../../scripts/helpers/parents.js":[function(require,module,exports) {
if (HTMLElement.parents === undefined) {
  HTMLElement.prototype.parents = function (selector) {
    var element = this;
    var result = [];
    var parent = element;

    while (parent && parent.matches) {
      if (selector) {
        if (parent.matches(selector)) {
          result.push(parent);
        }
      } else {
        result.push(parent);
      }

      parent = parent.parentNode;
    }

    return result;
  };

  SVGElement.prototype.parents = HTMLElement.prototype.parents;
}
},{}],"../../scripts/helpers/toArray.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.toArray = void 0;

//==================================================================================================
//
//	Convert an array-like object to an array
//
//==================================================================================================
var toArray = function toArray(obj) {
  if (obj && obj.length !== undefined) {
    return Array.prototype.slice.call(obj, 0);
  }

  return [obj];
};

exports.toArray = toArray;
},{}],"../../scripts/components/accordion/accordion.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Accordion
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var Accordion = function Accordion(element) {
  var accordion = this;
  accordion.wrappingElement = element;
  accordion.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the Accordion Element
 */


Accordion.prototype.init = function () {
  // Cache instance
  var accordion = this;
  accordion.defineItems();
  accordion.setDefault();
  accordion.attachEvents();
}; //==================================================================================================
//	Define Items
//==================================================================================================

/**
 * Defines the Accordion Items
 */


Accordion.prototype.defineItems = function () {
  var accordion = this; // array of accordion triggers

  accordion.triggers = (0, _toArray.toArray)(accordion.wrappingElement.querySelectorAll("[data-accordion-trigger]")); //array of accordion views

  accordion.views = (0, _toArray.toArray)(accordion.wrappingElement.querySelectorAll("[data-accordion-view]")); // default option

  accordion.defaultOption = accordion.wrappingElement.querySelector("[data-accordion-default-view]") || null;
}; //==================================================================================================
//	Set Default
//==================================================================================================

/**
 * Opens the accordion on default view if set
 */


Accordion.prototype.setDefault = function () {
  //cache instance
  var accordion = this; // if there is a default option set

  if (accordion.defaultOption) {
    // open accordion with default option
    accordion.openView(accordion.defaultOption); // remove the data-attribute

    accordion.defaultOption.removeAttribute("data-accordion-default-view");
  }
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attaches the events to Accordion
 */


Accordion.prototype.attachEvents = function () {
  // Cache instance
  var accordion = this; // Add keyboard navigation events

  accordion.wrappingElement.addEventListener("keyup", function (e) {
    // prevent form submission
    e.preventDefault(); // check whether activeElement is an accordion trigger

    if (document.activeElement.hasAttribute("data-accordion-trigger")) {
      // call keyboardAction function
      accordion.keyboardAction(e.keyCode);
    }
  }); // Add click listener to each trigger to open and close view

  accordion.triggers.forEach(function (trigger) {
    // on click
    trigger.addEventListener("click", function () {
      // call toggle function with trigger element
      accordion.toggleView(trigger);
    });
  });
}; //==================================================================================================
//	Toggle View
//==================================================================================================

/**
 * Toggle the accordion view
 */


Accordion.prototype.toggleView = function (trigger) {
  // cache instance
  var accordion = this; // check whether corresponding view is open

  var isOpen = trigger.getAttribute("aria-expanded") === "true"; // if open call close else, call open

  if (isOpen) {
    accordion.closeView(trigger);
  } else {
    accordion.openView(trigger);
  }
}; //==================================================================================================
//	Open View
//==================================================================================================

/**
 * Displays the accordion view
 */


Accordion.prototype.openView = function (triggerEl) {
  // cache instance
  var accordion = this; // get corresponding accordion view

  var targetView = accordion.views.find(function (el) {
    return el.id === triggerEl.getAttribute("aria-controls");
  }); // Change Icon

  accordion.changeIcon(triggerEl); // remove hide class

  targetView.classList.remove("hide"); // set aria-hidden to false

  targetView.setAttribute("aria-hidden", false); // set accessibility to change aria-expanded

  triggerEl.setAttribute("aria-expanded", true);
}; //==================================================================================================
//	Close View
//==================================================================================================

/**
 * Closes the accordion view
 */


Accordion.prototype.closeView = function (triggerEl) {
  // cache instance
  var accordion = this; // get corresponding accordion view

  var targetView = accordion.views.find(function (el) {
    return el.id === triggerEl.getAttribute("aria-controls");
  }); // add hide class

  targetView.classList.add("hide"); // set aria-hidden to false

  targetView.setAttribute("aria-hidden", false); // call change icon method

  accordion.changeIcon(triggerEl); // Set aria-expanded to false

  triggerEl.setAttribute("aria-expanded", false);
}; //==================================================================================================
//	Change Icon
//==================================================================================================

/**
 * Changes the trigger icon
 */


Accordion.prototype.changeIcon = function (triggerEl) {
  // cache instance
  var accordion = this; // get icon element

  var icon = triggerEl.querySelector(".axa-accordion-trigger__icon"); // change icon content based on current state

  icon.textContent = icon.textContent === "add" ? "remove" : "add";
}; //==================================================================================================
//	Keyboard Action
//==================================================================================================

/**
 * Remove the focused state from all option listitems
 */


Accordion.prototype.keyboardAction = function (keyCode) {
  // cache instance
  var accordion = this; // If key quals

  switch (keyCode) {
    // ArrowDown === 40
    case 40:
      // If focus is on a trigger
      var currentIndex = accordion.triggers.indexOf(document.activeElement);

      if (accordion.triggers.length === currentIndex + 1) {
        accordion.setFocus(accordion.triggers[0]);
      } else {
        accordion.setFocus(accordion.triggers[currentIndex + 1]);
      }

      break;
    // ArrowUp === 38

    case 38:
      var currentIndex = accordion.triggers.indexOf(document.activeElement);

      if (currentIndex === 0) {
        accordion.setFocus(accordion.triggers[accordion.triggers.length - 1]);
      } else {
        accordion.setFocus(accordion.triggers[currentIndex - 1]);
      }

      break;
    // Enter === 13

    case 13:
      break;
    // Space === 32

    case 32:
      // toggle view
      accordion.toggleView(document.activeElement);
      break;
    // Home === 36

    case 36:
      // select the first trigger
      accordion.setFocus(accordion.triggers[0]);
      break;
    // End === 35

    case 35:
      // select the last trigger
      accordion.setFocus(accordion.triggers[accordion.triggers.length - 1]);
      break;
  }
}; //==================================================================================================
//	Set Focus
//==================================================================================================

/**
 *Set the focus on trigger
 */


Accordion.prototype.setFocus = function (targetTrigger) {
  var accordion = this;
  targetTrigger.focus();
}; //==================================================================================================
//	Set Position
//==================================================================================================

/**
 *Set the selected and/or focused option item.
 */


Accordion.prototype.setPosition = function (direction) {
  var accordion = this; // if no selection made and no default

  if (select.activeIndex < 0) {
    if (direction === "forward") {
      // sleect the first option
      select.selectOption(select.options[0]);
    } else {
      // do nothing
      null;
    } // if selected option is at index 0

  } else if (select.activeIndex === 0) {
    // select the next item if direction if forwards, do nothing if the direction is backwards.
    direction === "forward" ? select.selectOption(select.options[1]) : select.selectOption(select.options[0]); // if selected option is the last option in the list
  } else if (select.activeIndex === select.options.length - 1) {
    // if direction is forward - do nothing, if backwards set selectedOption as being the previous option
    direction === "forward" ? select.selectOption(select.options[select.activeIndex]) : select.selectOption(select.options[select.activeIndex -= 1]); // if selection item is any other option in the list - move forwards or backwards by 1
  } else {
    direction === "forward" ? select.selectOption(select.options[select.activeIndex + 1]) : select.selectOption(select.options[select.activeIndex - 1]);
  }
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var accordions = (0, _toArray.toArray)(document.querySelectorAll("[data-accordion-group]"));

  if (accordions.length > 0) {
    accordions.forEach(function (element) {
      new Accordion(element);
    });
  }
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/helpers/debounce.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.debounce = void 0;

var debounce = function debounce(func, wait, immediate) {
  var timeout;
  return function executedFunction() {
    var context = this;
    var args = arguments;

    var later = function later() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };

    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
};

exports.debounce = debounce;
},{}],"../../scripts/components/autocomplete/autocomplete.js":[function(require,module,exports) {
"use strict";

var _debounce = require("../../helpers/debounce");

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Autocomplete
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var Autocomplete = function Autocomplete(element, allOptions) {
  // cache instance
  var autocomplete = this; // wrapping element

  autocomplete.element = element; // all permitted options

  autocomplete.allOptions = allOptions; // initialize autocomplete

  autocomplete.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the Autocomplete Element
 */


Autocomplete.prototype.init = function () {
  // Cache instance
  var autocomplete = this; // define items

  autocomplete.defineItems(); // set IDs

  autocomplete.setIDs(); // set width of list

  autocomplete.setWidth(); // attach event listeners

  autocomplete.attachEvents(); // function to limit calls to resize width of ul on window resize

  autocomplete.debounceResize = (0, _debounce.debounce)(function () {
    autocomplete.setWidth();
  }, 100);
}; //==================================================================================================
//	Define Items
//==================================================================================================

/**
 * Defines the autocomplete properties
 */


Autocomplete.prototype.defineItems = function () {
  // cache instance
  var autocomplete = this; // set default activeIndex to -1

  autocomplete.activeIndex = -1; // set default listOpen state to false

  autocomplete.listOpen = false; // set default activeItem state to null
  // autocomplete.activeItem = null;
  // autocomplete combobox, input and listbox wrapper

  autocomplete.wrapper = autocomplete.element.querySelector("[data-axa-autocomplete-wrapper]"); // autocomplete label

  autocomplete.label = autocomplete.element.querySelector("[data-axa-autocomplete-label]"); // autocomplete combobox element

  autocomplete.combobox = autocomplete.element.querySelector("[data-axa-autocomplete-combobox]"); // autocomplete input element

  autocomplete.input = autocomplete.element.querySelector("[data-axa-autocomplete-input"); // autocomplete list element

  autocomplete.list = autocomplete.element.querySelector("[data-axa-autocomplete-listbox"); // autocomplete filtered results

  autocomplete.filteredResults = [];
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attach the autocomplete events
 */


Autocomplete.prototype.attachEvents = function () {
  // cache instance
  var autocomplete = this;
  autocomplete.input.addEventListener("keydown", function (e) {
    autocomplete.navigationKeyPress(e);
  });
  autocomplete.input.addEventListener("keyup", function (e) {
    autocomplete.checkKey(e);
  });
  autocomplete.list.addEventListener("click", function (e) {
    autocomplete.clickOption(e);
  });
  autocomplete.input.addEventListener("blur", function (e) {
    autocomplete.checkResult(e);
  });
  window.addEventListener("resize", function () {
    autocomplete.debounceResize();
  });
}; //==================================================================================================
//	Search Results
//==================================================================================================

/**
 * Searches allOptions for matching results based on user input
 */


Autocomplete.prototype.searchResults = function (e) {
  // cache instance
  var autocomplete = this; // hide options list

  autocomplete.hideList(); //get search term as string

  var term = autocomplete.getInputValue(); // if no search term

  if (!term) {
    // reset filteredResults to empty array
    autocomplete.clearList();
    return;
  } // convert searchterm to regular expression


  var searchTerm = new RegExp(term, "i"); // Filter allOptions to return array containing matches

  var matchingResults = autocomplete.allOptions.filter(function (result) {
    return result.match(searchTerm);
  }); // create list with the matching options

  autocomplete.createList(matchingResults);
}; //==================================================================================================
//	Create List
//==================================================================================================

/**
 * Creates list element to populate results
 */


Autocomplete.prototype.createList = function (results) {
  // cache instance
  var autocomplete = this;

  if (!results.length) {
    autocomplete.hideList();
  } // Clear existing list


  autocomplete.clearList(); // call createOption for each element

  results.forEach(function (match) {
    autocomplete.createOption(match);
  }); // display list

  autocomplete.showList();
}; //==================================================================================================
//	Clear List
//==================================================================================================

/**
 * Clears filteredResults list and sets empty html for ul element
 */


Autocomplete.prototype.clearList = function () {
  // cache instance
  var autocomplete = this; // reset filteredResults

  autocomplete.filteredResults = []; // remove all innerHTML for ul element

  autocomplete.list.innerHTML = "";
}; //==================================================================================================
//	Create Option
//==================================================================================================

/**
 * Creates single option to populate results
 */


Autocomplete.prototype.createOption = function (result) {
  // cache instance
  var autocomplete = this; // convert textContent to lowercase single string

  var optionID = result.toLowerCase().replace(/ /g, "-"); // create new li element

  var option = document.createElement("li"); // set class name and attribute

  option.className = "axa-autocomplete__list-item";
  option.setAttribute("role", "option");
  option.setAttribute("aria-selected", false);
  option.setAttribute("tabindex", -1); // set id

  option.setAttribute("id", "result-option-" + optionID); // set innerText

  option.innerText = result; // append element to ul

  autocomplete.list.appendChild(option); //append to filteredResults

  autocomplete.filteredResults.push(option);
}; //==================================================================================================
//	Show List
//==================================================================================================

/**
 * Show result list
 */


Autocomplete.prototype.showList = function () {
  // cache instance
  var autocomplete = this; // get all li elements

  var options = autocomplete.getOptions(); // if any options

  if (options.length) {
    // set focus to first option
    autocomplete.setOptionFocus(0, false);
    autocomplete.listOpen = true;
    autocomplete.combobox.setAttribute("aria-expanded", true);
    autocomplete.list.classList.remove("hide");
    autocomplete.list.classList.add("axa-autocomplete__list--open"); // Add custom sytles to hide textbox default focus outline (as per design)

    autocomplete.input.classList.add("hide-focus-styles");
  }
}; //==================================================================================================
//	Hide List
//==================================================================================================

/**
 * Show result list
 */


Autocomplete.prototype.hideList = function () {
  // cache instance
  var autocomplete = this;
  autocomplete.listOpen = false;
  autocomplete.combobox.setAttribute("aria-expanded", false);
  autocomplete.list.classList.add("hide");
  autocomplete.list.classList.remove("axa-autocomplete__list--open");
  autocomplete.input.classList.remove("hide-focus-styles");
  autocomplete.input.setAttribute("aria-activedescendant", "");
}; //==================================================================================================
//	Click Option
//==================================================================================================

/**
 * Runs when list clicked by user
 */


Autocomplete.prototype.clickOption = function (e) {
  // cache instance
  var autocomplete = this; // If user clicks on an option

  if (autocomplete.getOptions().includes(e.target)) {
    // select that option
    autocomplete.selectOption(e.target); // hide the list

    autocomplete.hideList();
  }
}; //==================================================================================================
//	Select Option
//==================================================================================================

/**
 * Update the value of the input
 */


Autocomplete.prototype.selectOption = function (selectedOption) {
  // cache instance
  var autocomplete = this; // update activeIndex

  var newIndex = autocomplete.filteredResults.indexOf(selectedOption); // Update input value

  autocomplete.input.value = selectedOption.innerText; // update activeIndex property

  autocomplete.activeIndex = newIndex; // autocomplete.activeItem = selectedItem;
  // clear the filteredResults and ul html

  autocomplete.clearList();
}; //==================================================================================================
//	Set Width
//==================================================================================================

/**
 * Sets the width of the UL based on width of the button
 */


Autocomplete.prototype.setWidth = function () {
  //cache instance
  var autocomplete = this; // get width of button

  var width = autocomplete.input.offsetWidth; // set width of ul to match the button

  autocomplete.list.style.width = "" + width + "px";
}; //==================================================================================================
//	Clear Input Value
//==================================================================================================

/**
 * Sets input value to '';
 */


Autocomplete.prototype.clearInputValue = function () {
  //cache instance
  var autocomplete = this; // clear value of input

  autocomplete.input.value = "";
}; //==================================================================================================
//	Navigation Key Press
//==================================================================================================

/**
 *  Deals with user pressing navigation keys
 */


Autocomplete.prototype.navigationKeyPress = function (e) {
  // cache instance
  var autocomplete = this; // get event key.

  var key = e.key;

  switch (key) {
    // If enter
    case "Enter":
      // prevent form submission
      e.preventDefault();
      autocomplete.onEnterPress();
      return;

    case "Escape":
      // Clear input value and close list
      autocomplete.clearInputValue();
      autocomplete.hideList();
      return;
  } // Return fewer than two options


  if (autocomplete.filteredResults.length < 1) {
    return;
  }

  switch (key) {
    case "Home":
      autocomplete.setOptionFocus(0);
      break;

    case "End":
      autocomplete.setOptionFocus(autocomplete.filteredResults.length - 1);
      break;

    case "ArrowUp":
      e.preventDefault();
      autocomplete.onArrowPress(e.key);
      break;

    case "ArrowDown":
      e.preventDefault();
      autocomplete.onArrowPress(e.key);
      break;
  }
}; //==================================================================================================
//	On Enter Press
//==================================================================================================

/**
 * Deal with the user pressing Enter key
 */


Autocomplete.prototype.onEnterPress = function () {
  // cache instance
  var autocomplete = this; // if list is open

  if (autocomplete.listOpen) {
    // get the currently focused element
    var focusedElement = autocomplete.getFocusedOption(); // select that element

    autocomplete.selectOption(focusedElement); // close the list

    autocomplete.hideList();
  }
}; //==================================================================================================
//	On Arrow Press
//==================================================================================================

/**
 * Deal with the user pressing Arrow Keys
 */


Autocomplete.prototype.onArrowPress = function (key) {
  // cache instance
  var autocomplete = this; // get currently focused element

  var focusedOption = autocomplete.getFocusedOption(); // where there is a single result but activedescendant has not been set (i.e. where first option highlighted by default)

  if (autocomplete.filteredResults.length === 1 && !autocomplete.input.getAttribute("aria-activedescendant")) {
    // set activedescendant (allows screen readers to read option)
    return autocomplete.setActiveDescendant(focusedOption.id); // exit if single result and activedescendant has been set (renders arrow keys useless)
  } else if (autocomplete.filteredResults.length === 1 && autocomplete.input.getAttribute("aria-activedescendant")) {
    return;
  } // get index of currently focused element


  var focusedIndex = autocomplete.filteredResults.indexOf(focusedOption); // call naviagteOptions function with relevant direction

  autocomplete.navigateOptions(key === "ArrowDown" ? "down" : "up", focusedIndex);
}; //==================================================================================================
//	Navigate Options
//==================================================================================================

/**
 * Sets focus on next / previous option
 */


Autocomplete.prototype.navigateOptions = function (direction, prevIndex) {
  // cache instance
  var autocomplete = this; // calculate new index

  var newIndex = autocomplete.getNewIndex(direction, prevIndex); // set focus to option at new index

  autocomplete.setOptionFocus(newIndex);
}; //==================================================================================================
//	Set Option Focus
//==================================================================================================

/**
 * Add focus styles to option
 */


Autocomplete.prototype.setOptionFocus = function (newIndex) {
  var updateActiveDescendant = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  //cache instance
  var autocomplete = this;
  var newOption = autocomplete.filteredResults[newIndex]; // remove all focused styles

  autocomplete.clearFocusStates(); // add styles

  newOption.classList.add("focused"); //set aria-selected attribute

  newOption.setAttribute("aria-selected", true); // this check is to stop the first item in list (which is slected automatically) from being set as the activedescendant

  if (updateActiveDescendant) {
    // set activedescendant
    autocomplete.setActiveDescendant(newOption.id);
  }
}; //==================================================================================================
//	Set Active Descendant
//==================================================================================================

/**
 * Set inpput activeDescendant for accessibility
 */


Autocomplete.prototype.setActiveDescendant = function (id) {
  // cache instance
  var autocomplete = this;
  autocomplete.input.setAttribute("aria-activedescendant", id);
}; //==================================================================================================
//	Check Keys
//==================================================================================================

/**
 * Checks key pressed and calls search function if not navigation key
 */


Autocomplete.prototype.checkKey = function (e) {
  // cache instance
  var autocomplete = this; // call search function when not a navigation key

  switch (e.key) {
    case "Escape":
    case "ArrowUp":
    case "ArrowDown":
    case "Home":
    case "End":
    case "Tab":
    case "Enter":
      e.preventDefault();
      return;

    default:
      autocomplete.searchResults();
  }
}; //==================================================================================================
//	Check Result
//==================================================================================================

/**
 * Checks that input value matches an option, else clears input.
 */


Autocomplete.prototype.checkResult = function (e) {
  //cache instance
  var autocomplete = this; // return if the user has clicked on an li or the ul

  if (autocomplete.getOptions().includes(e.relatedTarget)) {
    return;
  } // get input value


  var result = autocomplete.getInputValue(); // check whether input is one of possible results (passed in on init)

  var isValid = autocomplete.allOptions.indexOf(result) !== -1; // if not one of possible results

  if (!isValid) {
    // if there are matching results
    if (autocomplete.filteredResults.length) {
      // get the current / last focused element
      var focusedOption = autocomplete.getFocusedOption(); // select that element

      autocomplete.selectOption(focusedOption);
    } else {
      // clear input where no matches
      autocomplete.clearInputValue();
    }
  } // hide list


  autocomplete.hideList();
}; //==================================================================================================
//	Get Input Value
//==================================================================================================

/**
 * Returns input value after trim
 */


Autocomplete.prototype.getInputValue = function (e) {
  //cache instance
  var autocomplete = this; // return result of calling trim on input value

  return autocomplete.input.value.trim();
}; //==================================================================================================
//	Get Options
//==================================================================================================

/**
 * Returns array of matching options
 */


Autocomplete.prototype.getOptions = function () {
  //cache instance
  var autocomplete = this; // return array of all matching options

  return (0, _toArray.toArray)(autocomplete.list.querySelectorAll(".axa-autocomplete__list-item"));
}; //==================================================================================================
//	Get Focused Option
//==================================================================================================

/**
 * Returns current/last focused option
 */


Autocomplete.prototype.getFocusedOption = function () {
  //cache instance
  var autocomplete = this; // return array of all matching options

  return autocomplete.list.querySelector(".focused");
}; //==================================================================================================
//	Get New Index
//==================================================================================================

/**
 * Returns new index for navigating options with keyboard
 */


Autocomplete.prototype.getNewIndex = function (direction, prevIndex) {
  //cache instance
  var autocomplete = this; // get length of filterResults

  var resultsLength = autocomplete.filteredResults.length;
  var newIndex; // calculate new index

  if (prevIndex === 0) {
    newIndex = direction === "down" ? prevIndex + 1 : resultsLength - 1;
  } else if (prevIndex + 1 === resultsLength) {
    newIndex = direction === "down" ? 0 : prevIndex - 1;
  } else {
    newIndex = direction === "down" ? prevIndex + 1 : prevIndex - 1;
  }

  return newIndex;
}; //==================================================================================================
//	Clear Focus States
//==================================================================================================

/**
 * Clear focus states and aria-selected attributes for all options
 */


Autocomplete.prototype.clearFocusStates = function () {
  // cache instance
  var autocomplete = this; // iterate through each option

  autocomplete.filteredResults.forEach(function (el) {
    if (el.classList.contains("focused")) {
      el.classList.remove("focused");
    }

    el.setAttribute("aria-selected", false);
  });
}; //==================================================================================================
//	Set IDs
//==================================================================================================

/**
 * Set Unique IDs for each element of the autocomplete to allow for improved screen reader support
 */


Autocomplete.prototype.setIDs = function () {
  // cache instance
  var autocomplete = this; //get id from label

  var idPrefix = autocomplete.label.id; // set combobox attributes

  autocomplete.combobox.id = "" + idPrefix + "-combobox";
  autocomplete.list.id = "" + idPrefix + "-listbox";
  autocomplete.input.id = "" + idPrefix + "-input";
  autocomplete.combobox.setAttribute("aria-owns", autocomplete.list.id);
  autocomplete.list.setAttribute("aria-labelledby", autocomplete.label.id); // set input attributes

  autocomplete.input.setAttribute("aria-labelledby", autocomplete.label.id);
  autocomplete.input.setAttribute("aria-controls", autocomplete.list.id);
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var autocompleteElements = (0, _toArray.toArray)(document.querySelectorAll("[data-axa-autocomplete]"));
  var occupations = ["Assistant teacher", "Dance teacher", "Deputy head teacher"];
  var countries = ["Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Anguilla", "Antigua &amp; Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia &amp; Herzegovina", "Botswana", "Brazil", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Cayman Islands", "Chad", "Chile", "China", "Colombia", "Congo", "Cook Islands", "Costa Rica", "Cote D Ivoire", "Croatia", "Cruise Ship", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Polynesia", "French West Indies", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea Bissau", "Guyana", "Haiti", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kuwait", "Kyrgyz Republic", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Mauritania", "Mauritius", "Mexico", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Namibia", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Norway", "Oman", "Pakistan", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russia", "Rwanda", "Saint Pierre &amp; Miquelon", "Samoa", "San Marino", "Satellite", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "South Africa", "South Korea", "Spain", "Sri Lanka", "St Kitts &amp; Nevis", "St Lucia", "St Vincent", "St. Lucia", "Sudan", "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor L'Este", "Togo", "Tonga", "Trinidad &amp; Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks &amp; Caicos", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Venezuela", "Vietnam", "Virgin Islands (US)", "Yemen", "Zambia", "Zimbabwe"];

  if (autocompleteElements.length > 0) {
    new Autocomplete(autocompleteElements[0], occupations);
    new Autocomplete(autocompleteElements[1], countries);
  }
});
},{"../../helpers/debounce":"../../scripts/helpers/debounce.js","../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/helpers/resize.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Resize = void 0;
//==================================================================================================
//
//	Resize event handler
//
//==================================================================================================
//==================================================================================================
//	Private variables
//==================================================================================================

/**
 * Queue of callbacks to be called when a resize event is fired
 * @private
 * @memberof Resize
 */
var callbacks = []; //==================================================================================================
//	We will assume if this object is imported the handler should be bound
//==================================================================================================

/**
 * Event listener added to the document to iterate through our callbacks
 * @private
 * @function listener
 * @memberof Resize
 * @param {Event} event - Event object passed to our callback by the event listener
 */

function listener(event) {
  callbacks.forEach(function iterateCallbacks(callback) {
    if (callback) {
      callback(event);
    }
  });
}

window.addEventListener("resize", listener); //==================================================================================================
//	Constructor
//==================================================================================================

/**
 * Wrapper for the browser resize event.
 * This has the added benefit of only one event handler being bound, and the ability to add/remove individual callbacks
 * @constructor
 * @param {Function} callback - Callback to be added to the resize queue
 * @property {Function} index - Position of our callback within the resize queue
 * @property {Function} callback - Local reference to the callback passed on instantiation
 * @example
 * let callback = function(event) { console.log(event); }
 * let resize = new Resize(callback);
 */

var Resize = function Resize(callback) {
  var resize = this;
  resize.callback = callback;
  resize.index = undefined;

  if (callback) {
    resize.attach(callback);
  }
}; //==================================================================================================
//	Method for adding the callback from this instance of Resize to the queue
//==================================================================================================

/**
 * Method to attach our callback to the resize queue
 * This is done automatically when the Resize object is instantiated
 */


exports.Resize = Resize;

Resize.prototype.attach = function () {
  var resize = this;

  if (resize.index === undefined) {
    resize.index = callbacks.length;
    callbacks[resize.index] = resize.callback;
  }

  return resize;
}; //==================================================================================================
//	Method for removing the callback from the queue
//==================================================================================================

/**
 * Method to detach our callback to the resize queue
 */


Resize.prototype.detach = function () {
  var resize = this;

  if (resize.index !== undefined) {
    callbacks[resize.index] = undefined;
    resize.index = undefined;
  }

  return resize;
}; //==================================================================================================
//	Expose our private queue array
//==================================================================================================

/**
 * Exposes our private callback collection
 * @returns {Array} - Callback collection
 */


Resize.prototype.getCallbacks = function () {
  return callbacks;
};
},{}],"../../scripts/components/back-to-top/back-to-top.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

var _resize = require("../../helpers/resize");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//  Private Functions
//==================================================================================================

/**
 * Function to animate in the opacity
 * @param {Array} args - The binded instance
 * @paran {HTMLElement} args[0] - The element to be checked / changed
 * @ignore
 */
function showBackToTop(args) {
  // Get Back To Top from the args
  var backToTop = args[0];
  var backToTopButton = backToTop.querySelector("[data-scroll-to]"); // Get current y offset

  var windowScroll = window.pageYOffset; // Get window height

  var body = document.body,
      html = document.documentElement;
  var windowHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight); // Working out 40% of window height

  var scrollMax = windowHeight * 0.4; //Is BackToTop visible right now?

  var canSeeBackToTop = backToTop.hasAttribute("data-back-to-top-show"); //If we are 40% scrolled down the page and BackToTop is not visible

  if (window.pageYOffset > scrollMax && !canSeeBackToTop) {
    //Show BackToTop
    backToTop.setAttribute("data-back-to-top-show", ""); //Accessibility: TabIndex On / Selectable

    if (backToTopButton) {
      backToTopButton.setAttribute("tabindex", "0");
    } //Else If we are not 40% scrolled down the page and BackToTop is visible

  } else if (window.pageYOffset < scrollMax && canSeeBackToTop) {
    //Hide BackToTop
    backToTop.removeAttribute("data-back-to-top-show"); //Accessibility: TabIndex Off / Non selectable

    if (backToTopButton) {
      backToTopButton.setAttribute("tabindex", "-1");
    }
  }
}

function scrollToTop() {
  var duration = 500; // cancel if already on top

  if (document.scrollingElement.scrollTop === 0) return;
  var cosParameter = document.scrollingElement.scrollTop / 2;
  var scrollCount = 0,
      oldTimestamp = null;

  function step(newTimestamp) {
    if (oldTimestamp !== null) {
      // if duration is 0 scrollCount will be Infinity
      scrollCount += Math.PI * (newTimestamp - oldTimestamp) / duration;
      if (scrollCount >= Math.PI) return document.scrollingElement.scrollTop = 0;
      document.scrollingElement.scrollTop = cosParameter + cosParameter * Math.cos(scrollCount);
    }

    oldTimestamp = newTimestamp;
    window.requestAnimationFrame(step);
  }

  window.requestAnimationFrame(step);
} //==================================================================================================
//
//	Back To Top Opacity
//  Shows/Hides Back To Top Button on scroll
//
//==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  // Select all back to top items
  var backToTopItems = (0, _toArray.toArray)(document.querySelectorAll("[data-back-to-top]")); // If elements exist

  if (backToTopItems.length > 0) {
    // Loop though back to top items
    backToTopItems.forEach(function (backToTopItem) {
      // Bind event to the item
      var showBackToTopBound = showBackToTop.bind(this, [backToTopItem]); // Add Scroll Event

      window.addEventListener("scroll", showBackToTopBound); // Add Resize Event

      new _resize.Resize(showBackToTopBound); // Attach events

      backToTopItem.addEventListener("touch", scrollToTop);
      backToTopItem.addEventListener("mousewheel", scrollToTop);
      backToTopItem.addEventListener("mousedown", scrollToTop);
      backToTopItem.addEventListener("keypress", function (e) {
        if (e.keyCode === 13) {
          scrollToTop();
        }
      }); // Call Scroll Bound

      showBackToTopBound();
    });
  }
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js","../../helpers/resize":"../../scripts/helpers/resize.js"}],"../../scripts/components/header/header.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Header
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var Header = function Header(element) {
  var header = this;
  header.wrappingElement = element;
  header.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the Header Element
 */


Header.prototype.init = function () {
  // Cache instance
  var header = this;
  header.defineItems();
  header.attachEvents();
}; //==================================================================================================
//	Define Items
//==================================================================================================

/**
 * Defines the Header Items
 */


Header.prototype.defineItems = function () {
  var header = this;
  header.menuButton = header.wrappingElement.querySelector(".axa-header__menu-btn");
  header.menuIcon = header.menuButton.querySelector(".material-icons");
  header.isMenuOpen = false;
  header.menuList = header.wrappingElement.querySelector(".axa-header__menu-list-container");
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attaches the events to Header
 */


Header.prototype.attachEvents = function () {
  // Cache instance
  var header = this;
  header.menuButton.addEventListener("click", function () {
    header.isMenuOpen ? header.closeMenu() : header.openMenu();
  }); // close menu if click on DOM

  window.addEventListener("click", function (e) {
    var isHeader = e.target.parents(".axa-header, .axa-header__menu-btn-icon");
    if (isHeader.length === 0) header.closeMenu();
  });
}; //==================================================================================================
//	Open Menu (Mobile)
//==================================================================================================

/**
 * Opens dropdown menu on mobile
 */


Header.prototype.openMenu = function () {
  // Cache instance
  var header = this;
  header.menuButton.setAttribute("aria-expanded", true);
  header.menuButton.innerHTML = "<span role='img' aria-hidden='true' class='axa-header__menu-btn-icon material-icons'>close</span>Close";
  header.menuList.classList.add("axa-header__menu-list-container--open");
  header.menuList.setAttribute("aria-hidden", false);
  header.isMenuOpen = true;
}; //==================================================================================================
//	Close Menu (Mobile)
//==================================================================================================

/**
 * Closes dropdown menu on mobile
 */


Header.prototype.closeMenu = function () {
  // Cache instance
  var header = this;
  header.menuButton.setAttribute("aria-expanded", false);
  header.menuButton.innerHTML = "<span role='img' aria-hidden='true' class='axa-header__menu-btn-icon material-icons'>menu</span> Menu";
  header.menuList.classList.remove("axa-header__menu-list-container--open");
  header.menuList.setAttribute("aria-hidden", true);
  header.isMenuOpen = false;
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var headers = (0, _toArray.toArray)(document.querySelectorAll(".axa-header"));
  headers.forEach(function (element) {
    var menu = element.querySelectorAll(".axa-header__menu-btn");

    if (menu.length > 0) {
      new Header(element);
    }
  });
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/components/radio-card/radio-card.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

var _parents = require("../../helpers/parents");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Accordion
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var RadioCard = function RadioCard(element) {
  var radioCard = this;
  radioCard.wrappingElement = element;
  radioCard.inputElement = radioCard.wrappingElement.querySelector(".axa-radio__input");
  radioCard.name = radioCard.inputElement.getAttribute("name");
  radioCard.siblings = document.querySelectorAll('[name="' + radioCard.name + '"]');
  radioCard.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the RadioCard Element
 */


RadioCard.prototype.init = function () {
  // Cache instance
  var radioCard = this;
  radioCard.attachEvents();
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attaches the events to RadioCard
 */


RadioCard.prototype.attachEvents = function () {
  // Cache instance
  var radioCard = this;
  radioCard.wrappingElement.addEventListener("click", function () {
    radioCard.toggleSelected();
  });
  radioCard.inputElement.addEventListener("focus", function () {
    radioCard.wrappingElement.classList.add("focused");
  });
  radioCard.inputElement.addEventListener("blur", function () {
    radioCard.wrappingElement.classList.remove("focused");
  });
}; //==================================================================================================
//	Toggle Selected
//==================================================================================================

/**
 * Toggles sleected classes on radio card
 */


RadioCard.prototype.toggleSelected = function () {
  // cache instance
  var radioCard = this; // Check the input

  radioCard.inputElement.checked = true;
  radioCard.inputElement.focus(); // remove selected from all siblings

  radioCard.siblings.forEach(function (el) {
    if (el !== radioCard.inputElement) {
      var parentEl = el.parents(".axa-radio-card")[0];
      parentEl.classList.remove("axa-radio-card--selected");
    }
  });
  radioCard.wrappingElement.classList.add("axa-radio-card--selected");
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var radioCardGroups = (0, _toArray.toArray)(document.querySelectorAll(".axa-radio-card"));

  if (radioCardGroups.length > 0) {
    radioCardGroups.forEach(function (element) {
      new RadioCard(element);
    });
  }
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js","../../helpers/parents":"../../scripts/helpers/parents.js"}],"../../scripts/components/select/select.js":[function(require,module,exports) {
"use strict";

var _debounce = require("../../helpers/debounce");

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Select
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var Select = function Select(element) {
  var select = this;
  select.wrappingElement = element;
  select.activeIndex = -1;
  select.selectedOption = null;
  select.optionsOpen = false;
  select.searchTerm = "";
  select.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the Select Element
 */


Select.prototype.init = function () {
  // Cache instance
  var select = this;
  select.defineItems();
  select.setWidth();
  select.setDefault();
  select.attachEvents();
}; //==================================================================================================
//	Set Width
//==================================================================================================

/**
 * Sets the width of the UL based on width of the button
 */


Select.prototype.setWidth = function () {
  //cache instance
  var select = this; // get width of button

  var width = select.searchWrapper.offsetWidth; // set width of ul to match the button

  select.optionsList.style.width = "" + width + "px";
}; //==================================================================================================
//	Define Items
//==================================================================================================

/**
 * Defines the Select Items
 */


Select.prototype.defineItems = function () {
  var select = this; // button clicked by user to interact with list

  select.searchWrapper = select.wrappingElement.querySelector("[data-axa-select-search-wrapper]"); //span element containing the selected option

  select.searchElement = select.wrappingElement.querySelector("[data-axa-select-search]"); // ul element containing the option items

  select.optionsList = select.wrappingElement.querySelector("[data-axa-select-list]"); // hidden input to be submitted for forms

  select.hiddenInput = select.wrappingElement.querySelector("[data-axa-select-value]"); // array of all options

  select.options = (0, _toArray.toArray)(select.wrappingElement.querySelectorAll("[data-axa-select-option]")); // any default option that should be set or false

  select.defaultOption = select.optionsList.querySelector("[data-axa-select-option-default") || false; // function to keyboard searches only when user stops typing

  select.debounceSearch = (0, _debounce.debounce)(function () {
    select.searchKey(select.searchTerm);
    select.searchTerm = "";
  }, 300); // function to limit calls to resize width of ul on window resize

  select.debounceResize = (0, _debounce.debounce)(function () {
    select.setWidth();
  }, 500);
}; //==================================================================================================
//	Set Default
//==================================================================================================

/**
 * Selects the defaultoption if one is set
 */


Select.prototype.setDefault = function () {
  //cache instance
  var select = this; // if there is a default option set

  if (select.defaultOption) {
    // select the default option
    this.selectOption(select.defaultOption); // remove the data-attribute

    select.defaultOption.removeAttribute("data-axa-select-option-default");
  }
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attaches the events to Select
 */


Select.prototype.attachEvents = function () {
  // Cache instance
  var select = this; // add focus styles when searchWrapper in focus

  select.searchWrapper.addEventListener("focus", function () {// select.addFocusState();
  }); // remove focus styles when searchWrapper out of focus

  select.searchWrapper.addEventListener("blur", function () {
    select.removeFocusState();
  }); // Add keyboard navigation events

  select.wrappingElement.addEventListener("keyup", function (e) {
    // prevent form submission
    e.preventDefault(); // call keyboardAction function

    select.keyboardAction(e.key);
  }); // Add keyboard search events

  select.wrappingElement.addEventListener("keyup", function (e) {
    // store event.key value as string
    select.searchTerm += e.key; // call debounceSearch to limit search

    select.debounceSearch();
  }); // prevent arrow DOM navigation when optionslist is open

  select.wrappingElement.addEventListener("keydown", function (e) {
    if (select.optionsOpen) {
      e.preventDefault();
    }
  }); // Add click listener to toggle open/close optionList

  select.searchWrapper.addEventListener("click", function () {
    select.optionsOpen ? select.closeOptionList() : select.openOptionList();
  }); // Add click listener to each option to select and close optionList

  select.options.forEach(function (option) {
    option.addEventListener("click", function () {
      // select the clicked option
      select.selectOption(option); // close the optionslist

      select.closeOptionList(); // set DOm focus to the searchWrapper

      select.searchWrapper.focus();
    });
  }); // when the optionList is not in DOM focus

  select.optionsList.addEventListener("blur", function (e) {
    // check whether the relatedTarget is either the searchWrapper or one of the options
    var isException = select.options.includes(e.relatedTarget) || select.searchWrapper === e.relatedTarget; // if it is not an exception (i.e. the user has clicked on another element)

    if (!isException) {
      // close the optionlist
      select.closeOptionList(); // set DOM docus to searchWrapper

      select.searchWrapper.focus();
    }
  }); // On window resize

  window.addEventListener("resize", function (e) {
    //debounce the setWidth function
    select.debounceResize();
  });
}; //==================================================================================================
//	Open Option List
//==================================================================================================

/**
 * Displays the option list
 */


Select.prototype.openOptionList = function () {
  // cache instance
  var select = this; // set top offset for option list

  select.setOffset(); // display optionList

  select.optionsList.classList.remove("hide"); // check to see whether selection is null. If so, select first option

  if (!select.selectedOption) {
    select.selectOption(select.options[0]);
  } // set optionOpen state to true


  select.optionsOpen = true; // Set aria-expanded to true

  select.searchWrapper.setAttribute("aria-expanded", true); // Add focus to options-list

  select.optionsList.focus(); // Add 'focused' class to wrapper so that styles make it appear to be in focus (workaround for IE's lack of focus-within)

  select.addFocusState();
}; //==================================================================================================
//	Set Offset
//==================================================================================================

/**
 * Sets the top and left offset for the options list
 */


Select.prototype.setOffset = function () {
  //cache instance
  var select = this; // get height of button

  var offsetHeight = select.searchWrapper.offsetHeight;
  var height = parseInt(offsetHeight) - 1; // set width of ul to match the button

  select.optionsList.style.top = "" + height + "px";
}; //==================================================================================================
//	Close Option List
//==================================================================================================

/**
 * Hides the option list
 */


Select.prototype.closeOptionList = function () {
  // cache instance
  var select = this; // hide optionList

  select.optionsList.classList.add("hide"); // set optionsOpen state to false

  select.optionsOpen = false; // Set aria-expanded to false

  select.searchWrapper.removeAttribute("aria-expanded");
}; //==================================================================================================
//	Select Option
//==================================================================================================

/**
 * Select an option from the option list
 */


Select.prototype.selectOption = function (option) {
  // Cache instance
  var select = this; // Set text input value to selected option

  var selectedText = option.innerText.trim();
  select.searchElement.innerText = selectedText; // Remove 'focused' class from all items and then add it to the selection option

  select.clearItems();
  option.classList.add("focused"); //Set span content to selectedText

  select.selectedOption = selectedText; // Set activeIndex to index of selected option.

  select.activeIndex = select.options.indexOf(option); // Set aria-selected to true for selected item

  option.setAttribute("aria-selected", true); // set aria-activedescendant of option-list to enable assistive tech to know which option is focussed.

  select.optionsList.setAttribute("aria-activedescendant", option.id); // Set value of hidden input for form submission.

  select.hiddenInput.value = selectedText;
}; //==================================================================================================
//	Clear Items
//==================================================================================================

/**
 * Remove the focused state from all option listitems
 */


Select.prototype.clearItems = function () {
  var select = this; // Iterate through all options

  select.options.forEach(function (option) {
    // remove 'focused state from each option
    option.classList.remove("focused"); // remove 'aria-selected' attribute from each option

    option.removeAttribute("aria-selected");
  });
}; //==================================================================================================
//	Keyboard Action
//==================================================================================================

/**
 * Remove the focused state from all option listitems
 */


Select.prototype.keyboardAction = function (key) {
  // cache instance
  var select = this; // If key quals

  switch (key) {
    case "ArrowDown":
      // If optionlist is closed
      if (!select.optionsOpen) {
        //open options list
        select.openOptionList();
      } // move current option position forward


      select.setPosition("forward");
      break;

    case "ArrowUp":
      // if optionlist is closed
      if (!select.optionsOpen) {
        //open option list
        select.openOptionList();
      } // move current option position backwards


      select.setPosition("backward");
      break;

    case "Escape":
      // If optionList is open
      if (select.optionsOpen) {
        //Close option list
        select.closeOptionList(); // Set focus to the searchElement

        select.searchWrapper.focus();
      }

      break;

    case "Enter":
      // If optionList is close - open it
      if (!select.optionsOpen) {
        select.openOptionList(); // If there is a selectedOption

        if (select.selectedOption) // call selectOption with that item
          select.selectOption(select.options[select.activeIndex]);
      } else {
        // Close the list
        select.closeOptionList(); // If there is a selected option (this will only fail when no option has been focused and where no default set)

        if (select.activeIndex !== -1) {
          //select the last focused option
          select.selectOption(select.options[select.activeIndex]);
        } //set DOM focus to searchWrapper


        select.searchWrapper.focus();
      }

      break;

    case "Home":
      // select the first option
      select.selectOption(select.options[0]);
      break;

    case "End":
      // select the last option
      select.selectOption(select.options[select.options.length - 1]);
  }
}; //==================================================================================================
//	Search Key
//==================================================================================================

/**
 * Find option based on user's keyboard search
 */


Select.prototype.searchKey = function (searchTerm) {
  // cache instance
  var select = this; // get array of options that match the search terms

  var aFilteredOptions = select.options.filter(function (option) {
    if (option.innerText.toUpperCase().startsWith(searchTerm.toUpperCase())) {
      return true;
    }
  }); // set currentItem if selectedItem matches the new search terms

  var currentItem = aFilteredOptions.find(function (option) {
    return option.innerText === select.selectedOption;
  }); // remove current item from the filtered array

  if (currentItem) {
    aFilteredOptions.splice(aFilteredOptions.indexOf(currentItem), 1);
  } // navigate to first element of the filtered array


  if (aFilteredOptions.length > 0) {
    this.selectOption(aFilteredOptions[0]);
  }
}; //==================================================================================================
//	Set Position
//==================================================================================================

/**
 *Set the selected and/or focused option item.
 */


Select.prototype.setPosition = function (direction) {
  var select = this; // if no selection made and no default

  if (select.activeIndex < 0) {
    if (direction === "forward") {
      // sleect the first option
      select.selectOption(select.options[0]);
    } else {
      // do nothing
      null;
    } // if selected option is at index 0

  } else if (select.activeIndex === 0) {
    // select the next item if direction if forwards, do nothing if the direction is backwards.
    direction === "forward" ? select.selectOption(select.options[1]) : select.selectOption(select.options[0]); // if selected option is the last option in the list
  } else if (select.activeIndex === select.options.length - 1) {
    // if direction is forward - do nothing, if backwards set selectedOption as being the previous option
    direction === "forward" ? select.selectOption(select.options[select.activeIndex]) : select.selectOption(select.options[select.activeIndex -= 1]); // if selection item is any other option in the list - move forwards or backwards by 1
  } else {
    direction === "forward" ? select.selectOption(select.options[select.activeIndex + 1]) : select.selectOption(select.options[select.activeIndex - 1]);
  }
}; //==================================================================================================
//	Add Focus State
//==================================================================================================

/**
 * Adds focused class to searchWrapper (necessary for when UL is in DOM focus but want to maintain styles around button)
 */


Select.prototype.addFocusState = function () {
  // cache instance
  var select = this; // add styles to element

  select.searchWrapper.classList.add("focused");
}; //==================================================================================================
//	Remove Focus State
//==================================================================================================

/**
 * Remove the focused state from all option listitems
 */


Select.prototype.removeFocusState = function () {
  // cache instance
  var select = this; // remove styles from element

  select.searchWrapper.classList.remove("focused");
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var selectElements = (0, _toArray.toArray)(document.querySelectorAll("[data-axa-select]"));
  selectElements.forEach(function (element) {
    window.test = new Select(element);
  });
});
},{"../../helpers/debounce":"../../scripts/helpers/debounce.js","../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/components/textarea/textarea.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Character Count
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var CharacterCount = function CharacterCount(element) {
  var CharacterCount = this;
  CharacterCount.wrappingElement = element;
  CharacterCount.init();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initiates the CharacterCount Element
 */


CharacterCount.prototype.init = function () {
  // Cache instance
  var characterCount = this;
  characterCount.defineItems();
  characterCount.attachEvents();
}; //==================================================================================================
//	Define Items
//==================================================================================================

/**
 * Defines the CharacterCount Items
 */


CharacterCount.prototype.defineItems = function () {
  var characterCount = this;
  characterCount.formgroupElement = characterCount.wrappingElement.querySelector("axa-form-group");
  characterCount.textareaElement = characterCount.wrappingElement.querySelector(".axa-textarea");
  characterCount.messageElement = characterCount.wrappingElement.querySelector(".axa-character-count__message");
  characterCount.characterLimit = parseInt(characterCount.wrappingElement.dataset.characterLimit);
  characterCount.charactersRemaining = characterCount.characterLimit;
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Attaches the events to CharacterCount
 */


CharacterCount.prototype.attachEvents = function () {
  // Cache instance
  var characterCount = this;
  characterCount.textareaElement.addEventListener("input", function () {
    characterCount.updateCount();
    characterCount.checkErrors();
    characterCount.updateMessage();
  });
}; //==================================================================================================
//	Update Character Remaining
//==================================================================================================

/**
 * Updates the character count
 */


CharacterCount.prototype.updateCount = function () {
  // Cache instance
  var characterCount = this; // add focus styles when searchWrapper in focus

  characterCount.charactersRemaining = characterCount.characterLimit - characterCount.textareaElement.value.length;
}; //==================================================================================================
//	Check Errors
//==================================================================================================

/**
 * Updates the character count
 */


CharacterCount.prototype.checkErrors = function () {
  // Cache instance
  var characterCount = this;
  characterCount.charactersRemaining < 0 ? characterCount.wrappingElement.classList.add("error") : characterCount.wrappingElement.classList.remove("error");
}; //==================================================================================================
//	Update Message
//==================================================================================================

/**
 * Updated the characters remaining message
 */


CharacterCount.prototype.updateMessage = function () {
  // Cache instance
  var characterCount = this;

  if (characterCount.charactersRemaining < 0) {
    characterCount.messageElement.innerHTML = "<i class=\"material-icons\">warning</i>You have ".concat(Math.abs(characterCount.charactersRemaining), " ").concat(characterCount.charactersRemaining == -1 ? "character" : "characters", " too many");
  } else {
    characterCount.messageElement.innerHTML = "".concat(characterCount.charactersRemaining, " characters left");
  }
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var characterCounts = (0, _toArray.toArray)(document.querySelectorAll(".axa-character-count"));

  if (characterCounts.length > 0) {
    characterCounts.forEach(function (element) {
      new CharacterCount(element);
    });
  }
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/components/contextual-help/contextual-help.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
// import { debounce } from "../../helpers/debounce";
//==================================================================================================
//
//	Contextual Help
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
// The contextual help is a work in progress. The designers have said that they want it to close on blur but only on Desktop.
//They are going to clarify expected behaviour when moving from tablet to desktop views and come back to me.
var ContextualHelp = function ContextualHelp(element) {
  var contextualHelp = this;
  contextualHelp.wrappingElement = element;
  contextualHelp.triggerButton = element.querySelector(".axa-contextual-help__button");
  contextualHelp.dialogue = element.querySelector(".axa-contextual-help__dialogue");
  contextualHelp.closeButton = element.querySelector(".axa-contextual-help__close-button");
  contextualHelp.attachEvents();
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Initiates the Select Element
 */


ContextualHelp.prototype.attachEvents = function () {
  // Cache instance
  var contextualHelp = this;
  contextualHelp.triggerButton.addEventListener("click", function () {
    contextualHelp.openDialogue();
  });
  contextualHelp.closeButton.addEventListener("click", function () {
    contextualHelp.closeDialogue();
  });
}; //==================================================================================================
//	Open Dialogue
//==================================================================================================

/**
 * Opens the dialogue
 */


ContextualHelp.prototype.openDialogue = function () {
  // Cache instance
  var contextualHelp = this;

  if (contextualHelp.dialogue.classList.contains("hide")) {
    contextualHelp.dialogue.classList.remove("hide");
  }

  contextualHelp.setFocus(contextualHelp.closeButton);
}; //==================================================================================================
//	Close Dialogue
//==================================================================================================

/**
 * Closes the dialogue
 */


ContextualHelp.prototype.closeDialogue = function () {
  // Cache instance
  var contextualHelp = this;

  if (!contextualHelp.dialogue.classList.contains("hide")) {
    contextualHelp.dialogue.classList.add("hide");
  }

  contextualHelp.setFocus(contextualHelp.triggerButton);
}; //==================================================================================================
//	Set Focus
//==================================================================================================

/**
 * Sets the page focus
 */


ContextualHelp.prototype.setFocus = function (elementToFocus) {
  // Cache instance
  var contextualHelp = this;
  elementToFocus.focus();
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var contextualHelpElements = (0, _toArray.toArray)(document.querySelectorAll(".axa-contextual-help"));
  contextualHelpElements.forEach(function (element) {
    new ContextualHelp(element);
  });
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/components/modal/modal.js":[function(require,module,exports) {
"use strict";

var _toArray = require("../../helpers/toArray");

//==================================================================================================
//	Dependencies
//==================================================================================================
//==================================================================================================
//
//	Modal
//
//==================================================================================================
//==================================================================================================
//	Constructor
//==================================================================================================
var Modal = function Modal(element) {
  var modal = this;
  modal.element = element;
  modal.triggerButton = document.querySelector("[data-modal-trigger=\"".concat(modal.element.id, "\"]"));
  modal.dialogue = modal.element.querySelector(".axa-modal__dialogue");
  modal.closeButton = modal.element.querySelector(".axa-modal__close-button");
  modal.header = modal.dialogue.querySelector(".axa-modal__header");
  modal.headerIsSticky = modal.header.classList.contains(".axa-modal__header--stiky");
  modal.init();
  modal.attachEvents();
}; //==================================================================================================
//	Init
//==================================================================================================

/**
 * Initialise the modal instance
 */


Modal.prototype.init = function () {
  // Cache instance
  var modal = this;
  modal.pageInteractiveEls = modal.getInteractiveElements();
}; //==================================================================================================
//	Attach Events
//==================================================================================================

/**
 * Initiates the Modal Element
 */


Modal.prototype.attachEvents = function () {
  // Cache instance
  var modal = this;
  modal.triggerButton.addEventListener("click", function () {
    modal.openDialogue();
  });
  modal.closeButton.addEventListener("click", function () {
    modal.closeDialogue();
  });
  window.addEventListener("keydown", function (e) {
    if (e.code === "Escape") {
      e.preventDefault();
      modal.closeDialogue();
    }
  });
  modal.dialogue.addEventListener("scroll", function () {
    // debounce this function
    if (modal.dialogue.scrollTop > 0) {
      if (modal.headerIsSticky) return;
      modal.addStickyHeader();
    } else {
      if (!modal.headerIsSticky) return;
      modal.removeStickyHeader();
    }
  });
}; //==================================================================================================
//	Open Dialogue
//==================================================================================================

/**
 * Opens the modal dialogue
 */


Modal.prototype.openDialogue = function () {
  // Cache instance
  var modal = this;
  modal.element.classList.remove("--close");
  modal.dialogue.setAttribute("aria-hidden", false);
  modal.toggleTabIndex(1); // modal.setAria(1);

  modal.setFocus(modal.closeButton);
}; //==================================================================================================
//	Toggle Tabindex
//==================================================================================================

/**
 * Toggles tabindecies on all page interactive elements
 */


Modal.prototype.toggleTabIndex = function (modalState) {
  // Cache instance
  var modal = this;
  modal.pageInteractiveEls.forEach(function (el) {
    el.setAttribute("tabIndex", modalState ? "-1" : "0");
  });
}; //==================================================================================================
//	Close Dialogue
//==================================================================================================

/**
 * Closes the modal dialogue
 */


Modal.prototype.closeDialogue = function () {
  // Cache instance
  var modal = this;
  modal.element.classList.add("--close");
  modal.dialogue.setAttribute("aria-hidden", true);
  modal.toggleTabIndex(0); // modal.setAria(0);

  modal.setFocus(modal.triggerButton);
}; //==================================================================================================
//	Set Focus
//==================================================================================================

/**
 * Sets the page focus
 */


Modal.prototype.setFocus = function (elementToFocus) {
  // Cache instance
  var modal = this;
  elementToFocus.focus();
}; //==================================================================================================
//	Add Sticky Header
//==================================================================================================

/**
 * Adds sticky banner on scoll
 */


Modal.prototype.addStickyHeader = function () {
  // Cache instance
  var modal = this;
  modal.header.classList.add("axa-modal__header--sticky");
  modal.headerIsSticky = true;
}; //==================================================================================================
//	Remove Sticky Header
//==================================================================================================

/**
 * Remove sticky banner on scoll
 */


Modal.prototype.removeStickyHeader = function () {
  // Cache instance
  var modal = this;
  modal.header.classList.remove("axa-modal__header--sticky");
  modal.headerIsSticky = false;
}; //==================================================================================================
//	Get Interactice  Elements
//==================================================================================================

/**
 * Returns list of interactive elements on page
 */


Modal.prototype.getInteractiveElements = function () {
  // Cache instance
  var modal = this;
  var selector = 'a:not([tabindex="-1"]), button:not([tabindex="-1"]), input:not([tabindex="-1"]), select:not([tabindex="-1"]), textarea:not([tabindex="-1"]), [contenteditable]:not([tabindex="-1"])';
  var interactiveEls = (0, _toArray.toArray)(document.querySelectorAll(selector)).filter(function (el) {
    return el.parents(".axa-modal__container").length < 1;
  });
  return interactiveEls;
}; //==================================================================================================


document.addEventListener("DOMContentLoaded", function () {
  var modals = (0, _toArray.toArray)(document.querySelectorAll(".axa-modal__container"));
  modals.forEach(function (element) {
    new Modal(element);
  });
});
},{"../../helpers/toArray":"../../scripts/helpers/toArray.js"}],"../../scripts/components/index.js":[function(require,module,exports) {
"use strict";

require("../helpers/parents");

require("./accordion/accordion");

require("./autocomplete/autocomplete");

require("./back-to-top/back-to-top");

require("./header/header");

require("./radio-card/radio-card");

require("./select/select");

require("./textarea/textarea");

require("./contextual-help/contextual-help");

require("./modal/modal");
},{"../helpers/parents":"../../scripts/helpers/parents.js","./accordion/accordion":"../../scripts/components/accordion/accordion.js","./autocomplete/autocomplete":"../../scripts/components/autocomplete/autocomplete.js","./back-to-top/back-to-top":"../../scripts/components/back-to-top/back-to-top.js","./header/header":"../../scripts/components/header/header.js","./radio-card/radio-card":"../../scripts/components/radio-card/radio-card.js","./select/select":"../../scripts/components/select/select.js","./textarea/textarea":"../../scripts/components/textarea/textarea.js","./contextual-help/contextual-help":"../../scripts/components/contextual-help/contextual-help.js","./modal/modal":"../../scripts/components/modal/modal.js"}],"../../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js":[function(require,module,exports) {
var global = arguments[3];
var OVERLAY_ID = '__parcel__error__overlay__';
var OldModule = module.bundle.Module;

function Module(moduleName) {
  OldModule.call(this, moduleName);
  this.hot = {
    data: module.bundle.hotData,
    _acceptCallbacks: [],
    _disposeCallbacks: [],
    accept: function (fn) {
      this._acceptCallbacks.push(fn || function () {});
    },
    dispose: function (fn) {
      this._disposeCallbacks.push(fn);
    }
  };
  module.bundle.hotData = null;
}

module.bundle.Module = Module;
var checkedAssets, assetsToAccept;
var parent = module.bundle.parent;

if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== 'undefined') {
  var hostname = "" || location.hostname;
  var protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = new WebSocket(protocol + '://' + hostname + ':' + "63166" + '/');

  ws.onmessage = function (event) {
    checkedAssets = {};
    assetsToAccept = [];
    var data = JSON.parse(event.data);

    if (data.type === 'update') {
      var handled = false;
      data.assets.forEach(function (asset) {
        if (!asset.isNew) {
          var didAccept = hmrAcceptCheck(global.parcelRequire, asset.id);

          if (didAccept) {
            handled = true;
          }
        }
      }); // Enable HMR for CSS by default.

      handled = handled || data.assets.every(function (asset) {
        return asset.type === 'css' && asset.generated.js;
      });

      if (handled) {
        console.clear();
        data.assets.forEach(function (asset) {
          hmrApply(global.parcelRequire, asset);
        });
        assetsToAccept.forEach(function (v) {
          hmrAcceptRun(v[0], v[1]);
        });
      } else if (location.reload) {
        // `location` global exists in a web worker context but lacks `.reload()` function.
        location.reload();
      }
    }

    if (data.type === 'reload') {
      ws.close();

      ws.onclose = function () {
        location.reload();
      };
    }

    if (data.type === 'error-resolved') {
      console.log('[parcel] ? Error resolved');
      removeErrorOverlay();
    }

    if (data.type === 'error') {
      console.error('[parcel] ??  ' + data.error.message + '\n' + data.error.stack);
      removeErrorOverlay();
      var overlay = createErrorOverlay(data);
      document.body.appendChild(overlay);
    }
  };
}

function removeErrorOverlay() {
  var overlay = document.getElementById(OVERLAY_ID);

  if (overlay) {
    overlay.remove();
  }
}

function createErrorOverlay(data) {
  var overlay = document.createElement('div');
  overlay.id = OVERLAY_ID; // html encode message and stack trace

  var message = document.createElement('div');
  var stackTrace = document.createElement('pre');
  message.innerText = data.error.message;
  stackTrace.innerText = data.error.stack;
  overlay.innerHTML = '<div style="background: black; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; opacity: 0.85; font-family: Menlo, Consolas, monospace; z-index: 9999;">' + '<span style="background: red; padding: 2px 4px; border-radius: 2px;">ERROR</span>' + '<span style="top: 2px; margin-left: 5px; position: relative;">??</span>' + '<div style="font-size: 18px; font-weight: bold; margin-top: 20px;">' + message.innerHTML + '</div>' + '<pre>' + stackTrace.innerHTML + '</pre>' + '</div>';
  return overlay;
}

function getParents(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return [];
  }

  var parents = [];
  var k, d, dep;

  for (k in modules) {
    for (d in modules[k][1]) {
      dep = modules[k][1][d];

      if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) {
        parents.push(k);
      }
    }
  }

  if (bundle.parent) {
    parents = parents.concat(getParents(bundle.parent, id));
  }

  return parents;
}

function hmrApply(bundle, asset) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (modules[asset.id] || !bundle.parent) {
    var fn = new Function('require', 'module', 'exports', asset.generated.js);
    asset.isNew = !modules[asset.id];
    modules[asset.id] = [fn, asset.deps];
  } else if (bundle.parent) {
    hmrApply(bundle.parent, asset);
  }
}

function hmrAcceptCheck(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (!modules[id] && bundle.parent) {
    return hmrAcceptCheck(bundle.parent, id);
  }

  if (checkedAssets[id]) {
    return;
  }

  checkedAssets[id] = true;
  var cached = bundle.cache[id];
  assetsToAccept.push([bundle, id]);

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    return true;
  }

  return getParents(global.parcelRequire, id).some(function (id) {
    return hmrAcceptCheck(global.parcelRequire, id);
  });
}

function hmrAcceptRun(bundle, id) {
  var cached = bundle.cache[id];
  bundle.hotData = {};

  if (cached) {
    cached.hot.data = bundle.hotData;
  }

  if (cached && cached.hot && cached.hot._disposeCallbacks.length) {
    cached.hot._disposeCallbacks.forEach(function (cb) {
      cb(bundle.hotData);
    });
  }

  delete bundle.cache[id];
  bundle(id);
  cached = bundle.cache[id];

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    cached.hot._acceptCallbacks.forEach(function (cb) {
      cb();
    });

    return true;
  }
}
},{}]},{},["../../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js","../../scripts/components/index.js"], null)
//# sourceMappingURL=components.0fe8438f.js.map